Cleer Money logo pack
=====================

cleer-money-logo-for-light-bg.svg / .png   Horizontal logo for white or light backgrounds
cleer-money-logo-for-dark-bg.svg / .png    Horizontal logo for dark backgrounds
cleer-money-mark-for-light-bg.svg / .png   Mark only, light backgrounds
cleer-money-mark-for-dark-bg.svg / .png    Mark only, dark backgrounds

PNGs have transparent backgrounds. SVG text is outlined, so no font is needed.
The name is written "Cleer Money" in running text.

Brand green: #16A34A
Ink:         #1E1F1C

Please do not recolour, stretch or add effects to the logo.
Questions: isaac@cleermoney.com.au
